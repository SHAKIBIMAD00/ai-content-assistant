<?php
// Placeholder UI hooks
