<?php
/*
Plugin Name: AI Content Assistant
Description: AI-powered content generation, SEO optimization, translations, and image suggestions for Gutenberg.
Version: 1.0
Author: Your Name
*/
if ( ! defined( 'ABSPATH' ) ) exit;
require_once plugin_dir_path( __FILE__ ) . 'includes/class-ai-api.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/class-seo-checker.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/class-ui-hooks.php';
add_action('init', function() {
    AI_Content_Assistant_UI_Hooks::register_gutenberg_panel();
});
